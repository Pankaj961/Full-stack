# AI Usage

I used AI assistance as a design and implementation partner, while making the final product and scope decisions myself.

## 1. MVP shaping
**AI suggested:** focusing on the learner loop instead of building a full LMS.

**Accepted:** Yes. This directly matches the assignment and keeps the prototype achievable in two days.

## 2. Evaluation approach
**AI suggested:** combining deterministic checks with a future LLM evaluator rather than treating one reference answer as the truth.

**Accepted:** Yes. The MVP uses deterministic checks because they are reproducible and explainable. LLM evaluation is described as an extension.

## 3. Domain modelling
**AI suggested:** Vehicle, ParkingSpot, ParkingLot, Ticket, and PricingStrategy as useful domain concepts.

**Accepted:** Yes, because they demonstrate responsibilities, relationships, and a clear change point for pricing.

## 4. Testing
**AI suggested:** testing failure/edge cases such as empty input, very short submissions, unknown problem IDs, and a strong valid design.

**Accepted:** Yes. These cases protect the core submission flow.

## 5. Scope control
**AI suggested:** avoiding Kubernetes/microservices and other HLD work.

**Accepted:** Yes. The assignment is primarily an LLD/domain-design exercise, so the prototype remains a simple Flask + SQLite application.

## Human judgement

I deliberately rejected the idea of presenting a single class diagram as the only correct solution. The evaluator provides design signals and improvement suggestions instead, because LLD can have multiple valid implementations.
