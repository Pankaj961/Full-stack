def evaluate(solution):
    text = solution.strip()
    lower = text.lower()
    feedback, strengths = [], []
    score = 100

    if len(text) < 80:
        return {
            "score": 0,
            "summary": "Submission is too short to evaluate meaningfully.",
            "strengths": [],
            "improvements": ["Add classes, responsibilities, relationships, and at least one design decision."],
        }

    required_terms = {
        "vehicle": "Model Vehicle as a domain abstraction instead of putting vehicle logic in ParkingLot.",
        "parkingspot": "Represent ParkingSpot explicitly with spot state and compatibility behaviour.",
        "parkinglot": "Keep orchestration in ParkingLot; avoid making it a god object.",
        "ticket": "Use Ticket to capture an active parking session.",
        "pricingstrategy": "Use a pricing strategy interface so fee calculation can change without modifying ParkingLot."
    }
    for term, advice in required_terms.items():
        if term in lower:
            strengths.append(f"Mentions {term.title()}.")
        else:
            score -= 12
            feedback.append(advice)

    if "interface" in lower or "abstract" in lower or "strategy" in lower:
        strengths.append("Shows awareness of abstractions and extensibility.")
    else:
        score -= 6
        feedback.append("Name at least one interface/abstraction and explain why it can vary.")

    relationship_words = ["has-a", "has a", "contains", "composition", "association", "uses", "depends"]
    if any(x in lower for x in relationship_words):
        strengths.append("Describes at least one object relationship.")
    else:
        score -= 8
        feedback.append("Make relationships explicit: e.g., ParkingLot contains spots and uses a PricingStrategy.")

    if any(x in lower for x in ["single responsibility", "srp", "responsibility"]):
        strengths.append("Discusses responsibilities.")
    else:
        score -= 5
        feedback.append("State one clear responsibility for each important class.")

    if "concurr" in lower or "thread" in lower:
        strengths.append("Considers concurrent parking operations.")
    else:
        feedback.append("Optional: briefly mention how double-booking could be prevented under concurrent requests.")

    if "god object" in lower or "god class" in lower:
        strengths.append("Recognizes the god-object risk.")
    else:
        feedback.append("Explain how you would keep ParkingLot from becoming a god class.")

    score = max(0, min(100, score))
    if score >= 80:
        summary = "Strong first attempt. The core domain model is visible; refine trade-offs and edge cases."
    elif score >= 60:
        summary = "Good foundation. Several important LLD responsibilities or abstractions need clearer separation."
    else:
        summary = "The idea is started, but the design needs more explicit classes, responsibilities, and relationships."

    return {"score": score, "summary": summary, "strengths": strengths, "improvements": feedback[:6]}
