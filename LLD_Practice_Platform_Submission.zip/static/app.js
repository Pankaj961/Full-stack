let currentProblem;
const $ = id => document.getElementById(id);

async function load() {
  const problems = await fetch("/api/problems").then(r => r.json());
  currentProblem = problems[0];
  $("problemCount").textContent = `${problems.length} focused problem`;
  $("title").textContent = currentProblem.title;
  $("statement").textContent = currentProblem.statement;
  $("requirements").innerHTML = currentProblem.requirements.map(x => `<li>${escapeHtml(x)}</li>`).join("");
  $("concepts").innerHTML = currentProblem.concepts.map(x => `<span>${escapeHtml(x)}</span>`).join("");
  loadHistory();
}
function escapeHtml(s){return s.replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[c]));}

$("submit").onclick = async () => {
  const solution = $("solution").value;
  $("status").textContent = "Evaluating…";
  const res = await fetch("/api/attempts", {
    method:"POST", headers:{"Content-Type":"application/json"},
    body:JSON.stringify({problem_id:currentProblem.id, solution})
  });
  const data = await res.json();
  if (!res.ok) { $("status").textContent = data.error; return; }
  $("status").textContent = "Saved to attempt history.";
  $("feedback").classList.remove("hidden");
  $("score").textContent = `${data.score}/100`;
  $("summary").textContent = data.summary;
  $("strengths").innerHTML = (data.strengths.length ? data.strengths : ["No strengths detected yet."]).map(x=>`<li>${escapeHtml(x)}</li>`).join("");
  $("improvements").innerHTML = data.improvements.map(x=>`<li>${escapeHtml(x)}</li>`).join("");
  loadHistory();
  $("feedback").scrollIntoView({behavior:"smooth"});
};

async function loadHistory(){
  const rows = await fetch("/api/attempts").then(r=>r.json());
  $("history").innerHTML = rows.length ? `<table><tbody>${rows.map(r=>`<tr><td><strong>Attempt #${r.id}</strong><br>${r.problem}</td><td><strong>${r.score}/100</strong></td><td>${new Date(r.created_at.replace(" ","T")+"Z").toLocaleString()}</td></tr>`).join("")}</tbody></table>` : `<p style="color:#667085">No attempts yet. Submit your first design above.</p>`;
}
load();
