from evaluator import evaluate

def test_short_submission_fails():
    result = evaluate("class A {}")
    assert result["score"] == 0

def test_strong_design_scores_well():
    solution = """
    class Vehicle { type }
    class Car extends Vehicle {}
    class Motorcycle extends Vehicle {}
    class ParkingSpot { isAvailable(); canFit(vehicle) }
    class ParkingLot { park(vehicle); exit(ticket); }
    class Ticket { entryTime; spot; vehicle; }
    interface PricingStrategy { calculate(ticket); }
    ParkingLot contains ParkingSpot objects and uses PricingStrategy.
    Each class has a clear responsibility; the strategy avoids a god class.
    """
    result = evaluate(solution)
    assert result["score"] >= 80

def test_missing_abstractions_are_flagged():
    result = evaluate("ParkingLot handles parking and billing. " * 4)
    assert any("PricingStrategy" in x for x in result["improvements"])

def test_empty_input_is_a_failure_case():
    result = evaluate("")
    assert result["score"] == 0
