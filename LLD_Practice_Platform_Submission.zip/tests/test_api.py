import pytest

flask = pytest.importorskip("flask")
from app import app, init_db

@pytest.fixture()
def client(tmp_path, monkeypatch):
    import app as module
    monkeypatch.setattr(module, "DB", tmp_path / "test.db")
    init_db()
    return app.test_client()

def test_empty_submission_rejected(client):
    r = client.post("/api/attempts", json={"problem_id": 1, "solution": ""})
    assert r.status_code == 400

def test_unknown_problem_rejected(client):
    r = client.post("/api/attempts", json={"problem_id": 99999, "solution": "class Vehicle {} " * 20})
    assert r.status_code == 404
