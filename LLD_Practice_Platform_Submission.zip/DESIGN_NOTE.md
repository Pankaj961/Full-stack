# Design Note — LLD Practice Platform

## MVP

The prototype has four visible stages:

1. **Problem:** one focused Parking Lot prompt with requirements and concepts.
2. **Design:** free-form text/pseudo-code submission.
3. **Feedback:** score, strengths, and improvement suggestions.
4. **Review:** chronological attempt history.

The prototype intentionally keeps the surface small.

## Domain model

### `Problem`
Owns the challenge statement and requirements.

### `Attempt`
Represents one learner submission for a problem. It stores the submitted solution, score, and feedback snapshot.

### `Evaluator`
Conceptual interface for evaluating a solution. The MVP implementation is deterministic. A future `LLMEvaluator` can implement the same contract.

### `Feedback`
Contains a score, summary, strengths, and improvements.

### LLD concepts inside the challenge

- `Vehicle` — vehicle abstraction.
- `Car` / `Motorcycle` — concrete vehicle types.
- `ParkingSpot` — availability and compatibility.
- `ParkingLot` — orchestration of parking and exit.
- `Ticket` — parking-session state.
- `PricingStrategy` — variable fee-calculation policy.

## Important relationships

`Problem 1 → many Attempts`.

Inside the learner's proposed domain model, `ParkingLot` contains/manages `ParkingSpot` objects and uses a `PricingStrategy`. A `Ticket` connects a vehicle's parking session with its assigned spot.

## Evaluator approach

The evaluator checks observable design signals instead of comparing against one canonical class diagram.

**Deterministic checks**
- Important domain classes mentioned.
- Interface/strategy/abstraction mentioned.
- Relationship language present.
- Responsibilities discussed.
- God-object risk discussed.
- Optional concurrency awareness.

The evaluator subtracts points for missing signals and returns concise explanations.

### Why this trade-off?

A deterministic evaluator is stable and explainable. It can be tested with unit tests and does not require an external AI service. It is intentionally not presented as proof that a design is “correct.”

## How another evaluator can be added

The API stores feedback separately from the attempt. A future evaluator adapter can receive:

```text
Problem + Requirements + Learner Solution + Rubric
```

and return the same feedback shape:

```json
{
  "score": 82,
  "summary": "...",
  "strengths": ["..."],
  "improvements": ["..."]
}
```

This makes evaluator choice replaceable without redesigning the learner journey.

## Slow or failed evaluation

The current evaluator is synchronous and local, so it is effectively immediate. If an LLM evaluator is introduced, the UI should show `Evaluating`, save the attempt as `pending`, and update it when the evaluator finishes. A failure should preserve the submission and allow retry rather than losing learner work.

## Scope boundaries

Not included: Kubernetes, microservices, sharding, CDN architecture, complex authentication, course management, payments, analytics dashboards, or production-scale deployment. A simple single-process app is sufficient for this assignment.
