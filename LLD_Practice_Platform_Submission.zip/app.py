from flask import Flask, jsonify, request, render_template, g
import sqlite3, json, re
from pathlib import Path

BASE = Path(__file__).resolve().parent
DB = BASE / "practice.db"
app = Flask(__name__, template_folder=str(BASE / "templates"), static_folder=str(BASE / "static"))

SCHEMA = """
CREATE TABLE IF NOT EXISTS problems (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 title TEXT NOT NULL,
 statement TEXT NOT NULL,
 requirements TEXT NOT NULL,
 concepts TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS attempts (
 id INTEGER PRIMARY KEY AUTOINCREMENT,
 problem_id INTEGER NOT NULL,
 solution TEXT NOT NULL,
 feedback TEXT NOT NULL,
 score INTEGER NOT NULL,
 created_at TEXT DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(problem_id) REFERENCES problems(id)
);
"""

SEED = {
    "title": "Parking Lot",
    "statement": "Design a parking-lot system that accepts vehicles, assigns suitable spots, releases spots on exit, and calculates parking fees.",
    "requirements": [
        "Support car and motorcycle vehicles.",
        "Keep parking spots grouped by vehicle type.",
        "Assign an available compatible spot when a vehicle enters.",
        "Release the spot when the vehicle exits.",
        "Calculate a fee using a pluggable pricing strategy."
    ],
    "concepts": ["Vehicle", "Car", "Motorcycle", "ParkingSpot", "ParkingLot", "Ticket", "PricingStrategy"]
}

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB)
        g.db.row_factory = sqlite3.Row
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    db = g.pop("db", None)
    if db:
        db.close()

def init_db():
    db = sqlite3.connect(DB)
    db.executescript(SCHEMA)
    if db.execute("SELECT COUNT(*) FROM problems").fetchone()[0] == 0:
        db.execute(
            "INSERT INTO problems(title, statement, requirements, concepts) VALUES(?,?,?,?)",
            (SEED["title"], SEED["statement"], json.dumps(SEED["requirements"]), json.dumps(SEED["concepts"]))
        )
    db.commit()
    db.close()

from evaluator import evaluate

@app.route("/")
def index():
    return render_template("index.html")

@app.get("/api/problems")
def problems():
    rows = get_db().execute("SELECT * FROM problems ORDER BY id").fetchall()
    return jsonify([{
        "id": r["id"], "title": r["title"], "statement": r["statement"],
        "requirements": json.loads(r["requirements"]), "concepts": json.loads(r["concepts"])
    } for r in rows])

@app.post("/api/attempts")
def create_attempt():
    data = request.get_json(silent=True) or {}
    problem_id = data.get("problem_id")
    solution = data.get("solution", "")
    if not isinstance(problem_id, int):
        return jsonify({"error": "problem_id must be an integer"}), 400
    if not isinstance(solution, str) or not solution.strip():
        return jsonify({"error": "solution is required"}), 400
    problem = get_db().execute("SELECT id FROM problems WHERE id=?", (problem_id,)).fetchone()
    if not problem:
        return jsonify({"error": "problem not found"}), 404

    result = evaluate(solution)
    db = get_db()
    cur = db.execute(
        "INSERT INTO attempts(problem_id, solution, feedback, score) VALUES(?,?,?,?)",
        (problem_id, solution, json.dumps(result), result["score"])
    )
    db.commit()
    result["attempt_id"] = cur.lastrowid
    return jsonify(result), 201

@app.get("/api/attempts")
def attempts():
    rows = get_db().execute("""
        SELECT attempts.*, problems.title
        FROM attempts JOIN problems ON problems.id = attempts.problem_id
        ORDER BY attempts.id DESC
    """).fetchall()
    return jsonify([{
        "id": r["id"], "problem": r["title"], "score": r["score"],
        "created_at": r["created_at"], "feedback": json.loads(r["feedback"])
    } for r in rows])

if __name__ == "__main__":
    init_db()
    app.run(debug=True)
