# LLD Practice Platform

A focused MVP for repeated Low-Level Design practice.

## User journey

**Choose problem → Think/design → Submit → Get feedback → Review → Try again**

The prototype intentionally avoids LMS features, microservices, Kubernetes, authentication, and other HLD scope.

## Features

- One focused Parking Lot LLD problem with explicit requirements.
- Free-form solution editor supporting text/pseudo-code.
- Explainable deterministic feedback:
  - domain classes
  - abstractions/interfaces
  - responsibilities
  - relationships
  - extensibility
  - god-object risk
- Attempt history stored in SQLite.
- API endpoints for problems and attempts.
- Four automated tests covering short input, empty input, invalid problem, and a strong design.

## Run locally

```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

Run tests:

```bash
pytest -q
```

## Key design decisions

- **Flask + SQLite:** smallest practical stack for a 2-day prototype.
- **Deterministic evaluator first:** predictable, explainable feedback without requiring an API key.
- **Strategy abstraction:** the evaluator can later be replaced by an LLM evaluator without changing the learner flow.
- **Attempt history:** feedback is stored with each submission so the learner can compare progress.

## Future extension

A production version could add versioned evaluator adapters, asynchronous LLM evaluation, rubric versions, diagrams, authentication, and multiple problems. Those are intentionally outside this MVP.

## Optional Docker run

```bash
docker build -t lld-practice .
docker run --rm -p 5000:5000 lld-practice
```

Then open `http://127.0.0.1:5000`.
