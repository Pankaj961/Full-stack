# Research Note — LLD Practice Platform

## 1. Problem

Low-Level Design practice is easy to start but difficult to evaluate. A learner can produce a plausible Parking Lot, Elevator, or Vending Machine design and still be unsure whether responsibilities, abstractions, relationships, and trade-offs are sound.

The core product opportunity is therefore not “teach LLD” or “build an LMS.” It is to create a tight practice loop that helps a learner make a design, receive useful feedback, and try again.

**Practice loop:** Choose problem → Think/design → Submit → Get feedback → Review → Try again.

## 2. What a meaningful attempt needs

A useful attempt needs enough context to make design decisions without turning the exercise into a specification document. The problem should state actors, functional requirements, important constraints, and a few likely change points. The learner should be free to answer using text, pseudo-code, a class diagram, or a combination.

For this MVP, Parking Lot is used because it naturally exposes object modelling questions: Vehicle hierarchy, ParkingSpot compatibility, Ticket lifecycle, ParkingLot orchestration, and variable pricing.

The submission should make at least four things visible:

1. **Objects/classes** — what entities exist?
2. **Responsibilities** — what does each object own or decide?
3. **Relationships** — who contains, uses, creates, or depends on whom?
4. **Trade-offs/extensibility** — what is likely to change and how is that isolated?

## 3. Feedback research and product implication

LLD rarely has one “correct” answer. Therefore feedback should not pretend that matching a reference class diagram is correctness. A better evaluator combines deterministic checks with explanation.

Deterministic checks are appropriate for observable properties: whether important domain concepts are represented, whether responsibilities are stated, and whether a relationship or abstraction is present. An AI evaluator can later be added for higher-order reasoning such as whether a trade-off is sensible or whether a proposed abstraction is over-engineered.

The MVP therefore uses a deterministic rubric. It gives a score plus two categories: **What worked** and **Improve next**. This keeps feedback explainable and gives the learner a concrete next iteration.

## 4. Evaluation model

A practical rubric can score:

- domain modelling and requirement coverage
- responsibility separation
- interfaces/abstractions
- relationships
- extensibility and trade-offs
- edge-case awareness

The evaluator should also communicate uncertainty. “Missing PricingStrategy” is more useful than “wrong design,” because multiple valid designs can exist.

## 5. Why attempt history matters

One-off feedback is less valuable than repeated practice. The product stores every submission and score so a learner can review previous attempts and improve the same design. A future version could show rubric-by-rubric progress and compare feedback across revisions.

## 6. Alternatives considered

**Reference-answer matching:** rejected as the primary evaluator because it can penalize valid designs.

**Pure LLM evaluation:** rejected for the MVP because results can vary and are harder to explain or reproduce. It remains a useful extension for nuanced reasoning.

**Large LMS:** rejected because the assignment explicitly prioritizes the learner journey and LLD/domain design rather than course management.

## 7. Product hypothesis

If a learner can complete a small LLD problem in minutes, receive concrete feedback tied to a transparent rubric, and immediately resubmit, repeated practice should become easier and more measurable than relying on passive examples or generic interview questions.
